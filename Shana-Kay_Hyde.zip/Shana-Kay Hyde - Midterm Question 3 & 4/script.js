// JavaScript source code
alert("Welcome to Albert Einstein's website!");

function changeBackground() {
    if (document.body.style.backgroundColor == "honeydew") {
        document.body.style.backgroundColor = "#fff9ed";
    } else {
        document.body.style.backgroundColor = "honeydew";
    }
}